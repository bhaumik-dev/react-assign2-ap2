import React from "react";

const EmployeeSearch = () => {
  return (
    <div>
      <h2>Employee Search</h2>
      {/* will add search functionality here in assignment 2 */}
    </div>
  );
};

export default EmployeeSearch;
